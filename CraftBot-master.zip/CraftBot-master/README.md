# CraftBot
Is a Discord bot written in C# and DSharpPlus, serving around 30 servers at the time of writing this. If you're interested of having it in your server, [click here](https://craftplacer.trexion.com/link?id=craftbot-add).

## Plugin Framework
The base ([CraftBot.Base](https://github.com/Craftplacer/CraftBot/tree/master/CraftBot.Base)) only handles the foundation of connecting to Discord. Where as the different plugins provide features and commands. This makes the bot modular, though as of right now only the official version of the bot is running, people can fork/download it and make their own plugins if they wish to.
