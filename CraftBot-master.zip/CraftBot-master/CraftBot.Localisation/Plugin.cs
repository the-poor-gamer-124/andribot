﻿using CraftBot.Base;

namespace CraftBot.Localisation
{
    public class Plugin : Base.Plugins.Plugin
    {

        public override string Author => "Craftplacer";
        public override string Name => "Localisation";
    }
}