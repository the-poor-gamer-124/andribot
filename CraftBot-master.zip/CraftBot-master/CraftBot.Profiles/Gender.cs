﻿namespace CraftBot.Profiles
{
    public enum ProfileGender : int
    {
        Unset = 0,
        Male = 1,
        Female = 2
    }
}