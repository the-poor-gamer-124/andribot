using System;

namespace WordsMatching
{
    /// <summary>
    /// Summary description for Soundex.
    /// </summary>
    internal class Soundex : ISimilarity
    {
        public float GetSimilarity(string string1, string string2) => 0;
        public Soundex()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}
